
package com.example.weighttracking_koda;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private EditText inputWeight;
    private TextView statusText;
    private Button btnAdd, btnProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputWeight = findViewById(R.id.inputWeight);
        statusText  = findViewById(R.id.statusText);
        btnAdd      = findViewById(R.id.btnAdd);
        btnProgress = findViewById(R.id.btnProgress);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeightEntry();
            }
        });

        btnProgress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ProgressActivity.class));
            }
        });
    }

    private void addWeightEntry() {
        String text = inputWeight.getText().toString().trim();

        // Input validation
        if (TextUtils.isEmpty(text)) {
            inputWeight.setError("Weight is required");
            return;
        }
        double weight;
        try {
            weight = Double.parseDouble(text);
        } catch (NumberFormatException nfe) {
            inputWeight.setError("Enter a valid number");
            return;
        }
        if (weight <= 0 || weight > 1500) {
            inputWeight.setError("Enter a realistic weight (0-1500)");
            return;
        }

        // Persist to SharedPreferences as a simple enhancement (DB tests can come later)
        SharedPreferences prefs = getSharedPreferences("weights_prefs", Context.MODE_PRIVATE);
        String json = prefs.getString("weights", "[]");
        try {
            JSONArray arr = new JSONArray(json);
            JSONObject obj = new JSONObject();
            obj.put("index", arr.length());
            obj.put("weight", weight);
            arr.put(obj);
            prefs.edit().putString("weights", arr.toString()).apply();
            statusText.setText("Added entry: " + weight);
            inputWeight.setText("");
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving entry", Toast.LENGTH_SHORT).show();
        }
    }
}
