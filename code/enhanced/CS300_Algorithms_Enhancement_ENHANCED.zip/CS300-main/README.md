# CS300 Data Structures and Algorithms Portfolio Submission

## Reflection

### What was the problem you were solving in the projects for this course?
In this course, I worked on designing and implementing an advising assistance program to manage course information efficiently. The goal was to use different data structures to store, sort, and retrieve course details.

### How did you approach the problem? 
Understanding data structures is crucial in software development. I evaluated the efficiency of vectors, hash tables, and binary search trees in terms of runtime and memory usage. This helped determine the best structure for storing and searching course data.

### How did you overcome any roadblocks?  
One challenge I faced was ensuring the program could correctly parse and load course data from a CSV file. The issue was caused by spaces in the filename, which I resolved by renaming the file and ensuring proper input handling.

### How has this project expanded your approach to designing software?  
I learned the importance of choosing the right data structure for performance optimization. Binary search trees provided efficient sorting and retrieval, while hash tables allowed fast lookups.

### How has this project evolved your programming skills?  
I have improved my ability to write clean, maintainable, and adaptable code. I now use better error handling, follow proper naming conventions, and write modular functions to improve readability.

---
This repository contains:
- **Project One:** Runtime and memory analysis document
- **Project Two:** C++ implementation of the course sorting function
