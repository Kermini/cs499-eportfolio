
import os
from datetime import timedelta

import pandas as pd
from pymongo import MongoClient
from bson.regex import Regex

from AnimalShelter import AnimalShelter

from flask import Flask, session
import dash
from dash import html, dcc, dash_table, Input, Output, State

# -------------------------
# Configuration
# -------------------------
MONGO_USER = os.getenv("MONGO_USER", "aacuser")     # demo default; override in env
MONGO_PASS = os.getenv("MONGO_PASS", "aacpassword") # demo default; override in env

server = Flask(__name__)
server.secret_key = os.getenv("SECRET_KEY", "dev-secret")
server.permanent_session_lifetime = timedelta(hours=8)

# Dash app mounted on Flask server
app = dash.Dash(__name__, server=server, suppress_callback_exceptions=True)
app.title = "Grazioso Salvare Dashboard"

# -------------------------
# Helpers
# -------------------------
def get_db():
    # Reuse the AnimalShelter helper for the animals collection
    return AnimalShelter(MONGO_USER, MONGO_PASS)

def get_users_collection():
    # Connect directly to seed/read users in same DB
    HOST = 'nv-desktop-services.apporto.com'
    PORT = 33224
    DB = 'AAC'
    client = MongoClient(f'mongodb://{MONGO_USER}:{MONGO_PASS}@{HOST}:{PORT}/?authSource={DB}')
    return client[DB]['users']

# -------------------------
# Layouts
# -------------------------
login_layout = html.Div([
    html.H2("Login to Grazioso Dashboard"),
    dcc.Input(id="login-username", placeholder="Username", type="text"),
    dcc.Input(id="login-password", placeholder="Password", type="password", style={"marginLeft": "8px"}),
    html.Button("Login", id="login-button", n_clicks=0, style={"marginLeft": "8px"}),
    html.Div(id="login-message", style={"marginTop": "12px", "color": "crimson"}),
])

dashboard_layout = html.Div([
    html.Div([
        html.H2("Grazioso Salvare - Animal Search"),
        html.Button("Logout", id="logout-button", n_clicks=0, style={"float":"right"}),
    ], style={"display":"flex","justifyContent":"space-between","alignItems":"center"}),

    html.Hr(),

    html.Div([
        dcc.Dropdown(
            id="filter-animal-type",
            options=[{"label": x, "value": x} for x in ["Dog", "Cat", "Bird", "Other"]],
            placeholder="Animal Type (optional)",
            multi=True,
        ),
        dcc.Input(id="filter-breed", placeholder="Breed contains...", type="text", style={"marginLeft": "8px"}),
        dcc.Dropdown(
            id="filter-sex",
            options=[{"label": x, "value": x} for x in ["Intact Male","Intact Female","Neutered Male","Spayed Female","Unknown"]],
            placeholder="Sex Upon Outcome (optional)",
            multi=True,
            style={"marginLeft": "8px"},
        ),
        dcc.Checklist(
            id="filter-fixed",
            options=[{"label":"Fixed only (spayed/neutered)","value":"fixed"}],
            value=[],
            style={"marginLeft": "8px","display":"inline-block"}
        ),
        html.Button("Search", id="search-button", n_clicks=0, style={"marginLeft": "12px"}),
    ], style={"display":"flex","flexWrap":"wrap","gap":"6px"}),

    html.Div(id="result-count", style={"marginTop":"10px"}),

    dash_table.DataTable(
        id="results-table",
        columns=[
            {"name":"animal_id","id":"animal_id"},
            {"name":"name","id":"name"},
            {"name":"animal_type","id":"animal_type"},
            {"name":"breed","id":"breed"},
            {"name":"sex_upon_outcome","id":"sex_upon_outcome"},
            {"name":"age_upon_outcome","id":"age_upon_outcome"},
        ],
        page_size=10,
        sort_action="native",
        filter_action="native",
        style_table={"overflowX":"auto","marginTop":"8px"},
        style_cell={"textAlign":"left","padding":"6px"},
    ),

    html.H3("Counts by Animal Type", style={"marginTop":"20px"}),
    dcc.Graph(id="type-bar")
], style={"padding":"16px"})

# Root layout with location + auth store for reactivity
app.layout = html.Div([
    dcc.Location(id="url"),
    dcc.Store(id="auth-state", data=False),
    html.Div(id="page-root")
])

# Render based on auth-state; also re-check server session in case of refresh
@app.callback(Output("page-root","children"), Input("url","pathname"), Input("auth-state","data"))
def render_page(_, auth):
    if session.get("logged_in") or auth:
        return dashboard_layout
    return login_layout

# Login
@app.callback(
    Output("auth-state","data"),
    Output("login-message","children"),
    Input("login-button","n_clicks"),
    State("login-username","value"),
    State("login-password","value"),
    prevent_initial_call=True
)
def do_login(n, u, p):
    if not u or not p:
        return False, "Enter username and password."
    # Try DB users first
    try:
        users = get_users_collection()
        user = users.find_one({"username": u})
        if user and user.get("password") == p:  # demo-only: plain text for instructional scope
            session["logged_in"] = True
            return True, ""
    except Exception as e:
        # Fall back to a demo credential
        if u == "admin" and p == "admin123":
            session["logged_in"] = True
            return True, ""
        return False, "Login error."
    return False, "Invalid credentials."

# Logout
@app.callback(Output("auth-state","data"), Input("logout-button","n_clicks"), prevent_initial_call=True)
def logout(_):
    session.clear()
    return False

# Search action
@app.callback(
    Output("results-table","data"),
    Output("result-count","children"),
    Output("type-bar","figure"),
    Input("search-button","n_clicks"),
    State("filter-animal-type","value"),
    State("filter-breed","value"),
    State("filter-sex","value"),
    State("filter-fixed","value"),
    prevent_initial_call=True
)
def run_search(n, animal_types, breed_text, sex_values, fixed_flags):
    if not (session.get("logged_in")):
        return [], "Not authenticated.", {}
    shelter = get_db()
    query = {}

    if animal_types:
        query["animal_type"] = {"$in": animal_types}
    if breed_text:
        query["breed"] = Regex(breed_text, "i")  # case-insensitive contains
    if sex_values:
        query["sex_upon_outcome"] = {"$in": sex_values}
    if fixed_flags and "fixed" in fixed_flags:
        query["sex_upon_outcome"] = {"$in": ["Neutered Male","Spayed Female"]}

    docs = shelter.read(query)[:200]  # cap results for UI
    df = pd.DataFrame(docs)
    if not df.empty and "_id" in df.columns:
        df.drop(columns=["_id"], inplace=True, errors="ignore")

    count_msg = f"Results: {len(df)}"

    # Simple bar chart by animal type
    if df.empty or "animal_type" not in df.columns:
        fig = {"data": [], "layout": {"title": "No data"}}
    else:
        counts = df["animal_type"].value_counts().reset_index()
        counts.columns = ["animal_type","count"]
        fig = {
            "data": [{
                "type":"bar",
                "x": counts["animal_type"],
                "y": counts["count"]
            }],
            "layout": {"margin":{"l":40,"r":10,"t":20,"b":40}}
        }

    return df.to_dict("records"), count_msg, fig

if __name__ == "__main__":
    app.run_server(debug=True, host="0.0.0.0", port=8050)
