# CS300 Algorithms & Data Structures Enhancement

This enhancement adds a **binary search** implementation and a **runtime comparison** against linear search.
It is delivered as an additional, self-contained program that benchmarks both algorithms over increasing input sizes.

## Files Added
- `alg_utils.h` — template functions for `linear_search` and `binary_search_index`.
- `Enhancement_Benchmark.cpp` — generates synthetic course IDs (CS100..CSN), runs both searches, and prints timings.
- `Makefile` — builds the benchmark with `g++`.

## Build
```bash
make
```

## Run
```bash
./Enhancement_Benchmark
```

## Output
A CSV table:
```
InputSize,LinearSearch_ns,BinarySearch_ns
1000,   12345,   456
5000,   67890,   500
...
```
Followed by a demo section showing both algorithms return the same index for a known key.

## Notes
- Data are pre-sorted so binary search is valid.
- The synthesized dataset avoids dependency on external files.
- This enhancement complements the original `ProjectTwo.cpp` codebase and is intended for ePortfolio demonstration.