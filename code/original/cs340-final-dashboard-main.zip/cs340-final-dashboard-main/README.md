# CS 340 Final Dashboard Project – Koda Ermini

## Reflection Journal

**How do you write programs that are maintainable, readable, and adaptable?**  
In this course, I focused on writing modular code by separating concerns. The CRUD Python module from Project One was designed to be reusable and clearly documented, with consistent naming conventions and exception handling. This made Project Two much easier because I could plug the module directly into the dashboard code without rewriting database logic. In the future, I could use this same CRUD module as the back-end connector for any application that needs to work with MongoDB.

**How do you approach a problem as a computer scientist?**  
I started by reviewing the functional requirements and breaking them into components. For instance, I separated data retrieval from UI logic using the MVC design pattern. Compared to previous assignments, this one emphasized user interaction and live database access, which forced me to consider performance, real-time updates, and user experience. In the future, I would reuse this design pattern and modular approach when building client applications with data-driven dashboards.

**What do computer scientists do, and why does it matter?**  
Computer scientists solve real-world problems using code. In this project, I helped Grazioso Salvare identify and visualize ideal dogs for search-and-rescue training using data-driven insights. This dashboard helps their team filter dogs by traits, visualize locations, and act quickly on available resources. This kind of solution matters because it bridges raw data with business action, improving decision-making and operations.
