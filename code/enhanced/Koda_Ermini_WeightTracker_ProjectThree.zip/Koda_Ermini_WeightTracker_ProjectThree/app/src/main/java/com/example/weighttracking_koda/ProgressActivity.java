
package com.example.weighttracking_koda;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ProgressActivity extends AppCompatActivity {

    private LineChart chart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        chart = findViewById(R.id.lineChart);

        List<Entry> entries = loadWeightEntries();
        if (entries.isEmpty()) {
            Toast.makeText(this, "No weight data yet. Add entries on the main screen.", Toast.LENGTH_LONG).show();
        }

        LineDataSet dataSet = new LineDataSet(entries, "Weight Over Time");
        dataSet.setLineWidth(2f);
        dataSet.setCircleRadius(3f);
        dataSet.setDrawValues(false);

        LineData lineData = new LineData(dataSet);
        chart.setData(lineData);
        chart.getDescription().setEnabled(false);
        chart.getAxisRight().setEnabled(false);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);

        chart.invalidate();
    }

    private List<Entry> loadWeightEntries() {
        List<Entry> list = new ArrayList<>();
        SharedPreferences prefs = getSharedPreferences("weights_prefs", Context.MODE_PRIVATE);
        String json = prefs.getString("weights", "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                float x = (float) obj.getInt("index");
                float y = (float) obj.getDouble("weight");
                list.add(new Entry(x, y));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }
}
