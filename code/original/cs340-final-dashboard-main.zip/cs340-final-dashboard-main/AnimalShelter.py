from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33224
        DB = 'AAC'
        COL = 'animals'

        try:
            self.client = MongoClient(
                f'mongodb://{username}:{password}@{HOST}:{PORT}/?authSource={DB}'
            )
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except Exception as e:
            print(f"Failed to connect to MongoDB: {e}")
            raise

    def create(self, data):
        """Insert a new document into the collection."""
        if data is not None:
            try:
                insert_result = self.collection.insert_one(data)
                return True if insert_result.acknowledged else False
            except Exception as e:
                print(f"Insert failed: {e}")
                return False
        else:
            raise Exception("Nothing to save, data parameter is empty")

    def read(self, query, projection=None):
        """Retrieve documents from the collection based on a query and optional projection."""
        if query is not None:
            try:
                result = list(self.collection.find(query, projection))
                return result
            except Exception as e:
                print(f"Read failed: {e}")
                return []
        else:
            raise Exception("Nothing to query, query parameter is empty")

    def update(self, query, new_values):
        """Update document(s) matching the query with the new values."""
        if query is not None and new_values is not None:
            try:
                update_result = self.collection.update_many(query, {'$set': new_values})
                return update_result.modified_count
            except Exception as e:
                print(f"Update failed: {e}")
                return 0
        else:
            raise Exception("Query or new_values parameter is empty")

    def delete(self, query):
        """Delete document(s) matching the query."""
        if query is not None:
            try:
                delete_result = self.collection.delete_many(query)
                return delete_result.deleted_count
            except Exception as e:
                print(f"Delete failed: {e}")
                return 0
        else:
            raise Exception("Nothing to delete, query parameter is empty")

