# CS340 Database Enhancement

This enhancement adds **authentication** and **query filtering** to the Grazioso Salvare dashboard.

## What's New
- **Login screen** (session-based). Uses users in the `AAC.users` collection when available;
  otherwise accepts demo credentials `admin/admin123` for instructional use.
- **Query filtering UI**: filter by animal type, breed substring, sex upon outcome, and "fixed only".
- **Chart**: simple bar chart of results by animal type.
- **Safer patterns**: input is validated/escaped via query operators; results are capped for UI.

## Run
1. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
2. Set Mongo credentials (or leave demo defaults):
   ```bash
   export MONGO_USER=aacuser
   export MONGO_PASS=aacpassword
   export SECRET_KEY=change-me
   ```
3. Start the app:
   ```bash
   python app.py
   ```
4. Login with an account stored in `AAC.users` (if present) or use **admin/admin123** (demo).

## Notes
- The underlying Mongo connectivity and `AnimalShelter` helper remain unchanged.
- For production, replace the demo credential path with hashed-password verification.

### Demo Login
Use `admin / admin123` if you do not have a `AAC.users` document.
