#ifndef ALG_UTILS_H
#define ALG_UTILS_H

#include <vector>
#include <functional>
#include <optional>

// Linear search over a vector using a comparator that returns 0 on match
template <typename T>
std::optional<size_t> linear_search(const std::vector<T>& data, const T& key) {
    for (size_t i = 0; i < data.size(); ++i) {
        if (data[i] == key) return i;
    }
    return std::nullopt;
}

// Binary search over a sorted vector
template <typename T>
std::optional<size_t> binary_search_index(const std::vector<T>& sorted, const T& key) {
    size_t lo = 0, hi = sorted.size();
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        if (sorted[mid] == key) return mid;
        if (sorted[mid] < key) lo = mid + 1;
        else hi = mid;
    }
    return std::nullopt;
}

#endif // ALG_UTILS_H