#include <bits/stdc++.h>
#include "alg_utils.h"

using namespace std;
using namespace std::chrono;

// Synthesize course IDs like CS100, CS101, ..., CSN
static vector<string> make_course_ids(size_t n) {
    vector<string> ids;
    ids.reserve(n);
    for (size_t i = 0; i < n; ++i) {
        ids.push_back("CS" + to_string(100 + i));
    }
    return ids;
}

template <typename Fn>
long long time_once(Fn&& fn) {
    auto t0 = high_resolution_clock::now();
    fn();
    auto t1 = high_resolution_clock::now();
    return duration_cast<nanoseconds>(t1 - t0).count();
}

struct Result { size_t n; long long ns_linear; long long ns_binary; };

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    vector<size_t> sizes = {1000, 5000, 10000, 50000, 100000};
    vector<Result> results;

    for (size_t n : sizes) {
        auto ids = make_course_ids(n);
        auto sorted_ids = ids; // already sorted by construction

        // pick a key near end to avoid best-case skew
        string key = "CS" + to_string(100 + (n*9)/10);

        long long t_linear = time_once([&]{
            volatile auto idx = linear_search(ids, key);
            (void)idx;
        });

        long long t_binary = time_once([&]{
            volatile auto idx = binary_search_index(sorted_ids, key);
            (void)idx;
        });

        results.push_back({n, t_linear, t_binary});
    }

    cout << "InputSize,LinearSearch_ns,BinarySearch_ns\n";
    for (auto& r : results) {
        cout << r.n << "," << r.ns_linear << "," << r.ns_binary << "\n";
    }

    // Quick demonstration of correctness on a small set
    auto demo = make_course_ids(10);
    auto key = string("CS105");
    auto idx_lin = linear_search(demo, key);
    auto idx_bin = binary_search_index(demo, key);
    cout << "\nDemo: searching for " << key << " in 10-element set\n";
    cout << "Linear index: " << (idx_lin ? to_string(*idx_lin) : string("not found")) << "\n";
    cout << "Binary index: " << (idx_bin ? to_string(*idx_bin) : string("not found")) << "\n";

    return 0;
}