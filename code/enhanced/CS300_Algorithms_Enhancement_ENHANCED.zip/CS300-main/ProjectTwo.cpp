#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <algorithm>
#include <string>
#include <limits> // For numeric_limits

using namespace std;

// Course structure
struct Course {
    string courseId;        // Course number
    string title;           // Course title
    vector<string> prerequisites; // List of prerequisites
};

// Function prototypes
void displayMenu();
void loadCourses(map<string, Course>& courses);
void printCourseList(const map<string, Course>& courses);
void printCourse(const map<string, Course>& courses);
string toUpperCase(const string& input);

int main() {
    map<string, Course> courses; // Map to store courses for efficient lookups
    int choice = 0;

    cout << "Welcome to the course planner." << endl;

    while (choice != 9) {
        displayMenu();
        cout << "What would you like to do? ";
        cin >> choice;

        // Validate user input
        if (cin.fail()) {
            cout << "Invalid input. Please enter a number between 1 and 9." << endl;
            cin.clear(); // Clear error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore invalid input
            continue;
        }

        switch (choice) {
        case 1:
            loadCourses(courses);
            break;
        case 2:
            printCourseList(courses);
            break;
        case 3:
            printCourse(courses);
            break;
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            break;
        default:
            cout << choice << " is not a valid option." << endl;
        }
    }

    return 0;
}

// Function to display the main menu
void displayMenu() {
    cout << "\n1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit." << endl;
}

// Function to load courses from a CSV file
void loadCourses(map<string, Course>& courses) {
    string fileName;
    cout << "Enter the file name to load: ";
    cin.ignore(); // Clear the input buffer
    getline(cin, fileName); // Use getline to capture the full input

    // Remove any quotes around the file name
    fileName.erase(remove(fileName.begin(), fileName.end(), '\"'), fileName.end());

    cout << "Attempting to open file: " << fileName << endl;

    ifstream file(fileName);
    if (!file.is_open()) {
        cout << "Error: Could not open file \"" << fileName << "\"." << endl;
        cout << "File not found in the current directory either." << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string courseId, title, prereq;
        vector<string> prerequisites;

        // Parse courseId and title
        getline(ss, courseId, ',');
        getline(ss, title, ',');

        // Parse prerequisites
        while (getline(ss, prereq, ',')) {
            prerequisites.push_back(prereq);
        }

        // Create a course object and add it to the map
        Course course = { courseId, title, prerequisites };
        courses[courseId] = course;
    }

    file.close();
    cout << "Courses loaded successfully!" << endl;
}




// Function to print all courses in alphanumeric order
void printCourseList(const map<string, Course>& courses) {
    if (courses.empty()) {
        cout << "No courses available. Please load the data first." << endl;
        return;
    }

    cout << "\nHere is a sample schedule:\n" << endl;

    for (const auto& pair : courses) {
        cout << pair.first << ", " << pair.second.title << endl;
    }
}

// Function to print a specific course and its prerequisites
void printCourse(const map<string, Course>& courses) {
    if (courses.empty()) {
        cout << "No courses available. Please load the data first." << endl;
        return;
    }

    string courseId;
    cout << "What course do you want to know about? ";
    cin >> courseId;
    courseId = toUpperCase(courseId); // Convert input to uppercase for consistency

    auto it = courses.find(courseId);
    if (it != courses.end()) {
        const Course& course = it->second;
        cout << course.courseId << ", " << course.title << endl;
        if (!course.prerequisites.empty()) {
            cout << "Prerequisites: ";
            for (size_t i = 0; i < course.prerequisites.size(); ++i) {
                cout << course.prerequisites[i];
                if (i < course.prerequisites.size() - 1) cout << ", ";
            }
            cout << endl;
        }
        else {
            cout << "Prerequisites: None" << endl;
        }
    }
    else {
        cout << "Course not found." << endl;
    }
}

// Helper function to convert a string to uppercase
string toUpperCase(const string& input) {
    string result = input;
    transform(result.begin(), result.end(), result.begin(), ::toupper);
    return result;
}
